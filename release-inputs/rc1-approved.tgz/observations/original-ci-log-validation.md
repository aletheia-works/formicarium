# Raw CI log reconciliation

検証済み：mainでrun38040455333の原artifactから9必須checkのstdout/stderrを読み、各観測JSONのSHA256と一致、exit0、timeoutなしをassertした。非native7checkは製品parseTestSummaryで原ログを解析し、acceptanceの35/54/36/115/123/30/45件と一致、skip0。native2checkも原ログdigest/exit0を照合した。コマンドexit0。原データは/private/tmp/formicarium-u4-publication-boundary-ci-raw-v1/ci-results/に保持。集計だけを根拠に成功とはしていない。

初回の境界ログ照合ではTAPの`# tests`表記を仮定したassertが失敗した。実CIはNode spec reporterの`ℹ tests`表記だった。原ログのtests74/pass74/fail0を正しい形式で再assertしexit0。試験本体の失敗ではない。
